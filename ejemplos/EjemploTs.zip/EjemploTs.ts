let nombre = 'Mundo';
let mensaje: String = '¡Hola ' + nombre + '!';
console.log(mensaje);

for (let i: number = 0; i < 10; i++) {
  console.log('i=' + i);
}
