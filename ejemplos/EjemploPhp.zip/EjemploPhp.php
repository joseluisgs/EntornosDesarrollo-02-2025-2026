$nombre = "Mundo"
$mensaje = "¡Hola $nombre!"

echo $mensaje . "\n";

for ($i = 0; $i < 10; $i++) {
    echo "i=$i\n";
}